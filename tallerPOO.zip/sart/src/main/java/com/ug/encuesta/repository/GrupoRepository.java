package com.ug.encuesta.repository;
import org.springframework.data.repository.CrudRepository;
import com.ug.encuesta.dominio.Grupo;

public interface GrupoRepository extends CrudRepository <Grupo, Integer>{

}
