package com.ug.encuesta.repository;

import org.springframework.data.repository.CrudRepository;

import com.ug.encuesta.dominio.Subgrupo;

public interface SubgrupoRepository extends CrudRepository <Subgrupo, Integer>{

}
